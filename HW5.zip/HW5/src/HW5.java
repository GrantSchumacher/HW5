import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;
/**
 * CS2 HW5
 * HW5.java
 * Purpose: Takes in text file, converts to list of Strings of each individual word, removes special characters, counts number of identical word occurrences
 * 			exports words and occurrences to text file, prints number of unique words.
 * @author grantschumacher
 * @version 1.0 9/29/17
 */
public class HW5 {
	
	int uniqueWords;
	ArrayList<String> words = new ArrayList<String>();
	LinkedList<String> wordsLL = new LinkedList<String>();
	ArrayList<Word> wordsArray = new ArrayList<Word>();
	public static void main(String args[]){
		HW5 h = new HW5();
		Scanner sc = new Scanner(System.in);
		System.out.print("FileName: ");
		h.readFile(sc.nextLine());
		h.createWordsArray();
		h.exportWordsArray();
		sc.close();
	}
	
	/**
	 * Takes in fileName, reads data from file, removes special characters, populates array with words
	 * @param fileName
	 */
	public void readFile(String fileName){
		String word;
		
		try{
			File file = new File(fileName);
			Scanner inputFile = new Scanner(file);

			while (inputFile.hasNext()) { //read file until end of text
				word = inputFile.next(); //read each word
				word = word.toLowerCase(); //Make all words lower case
				word = word.replaceAll("[^a-zA-Z0-9']",""); //Remove special characters excluding apostrophe
				words.add(word);
				wordsLL.add(word);
				
			}
			Collections.sort(words); //Sort the array list
			Collections.sort(wordsLL); //Sort the linked list
			inputFile.close();
		}catch(Exception ex){
			System.out.println(ex);
		}
		
	}
	
	/**
	 * Takes each word and occurrence, creates an instance of Word and populates it with data
	 */
	public void createWordsArray(){
		int counter = 0;
		String firstWord =""; //Used to mark first occurrence of a word
		String secondWord =""; //Used to check number of occurrences
		try{
		for(int i = 0; i < words.size(); i++){ //Pick first occurrence of a word
			firstWord = words.get(i); 
			counter = 0; //Reset the counter
			for(int x = i+1; x < words.size(); x++){ //Run through words until firstWord no longer matches second word
				secondWord = words.get(x);
				if(secondWord.equals(firstWord)){ //If the words are still the same add to counter
					counter++;
				}else{ //Otherwise, if words are not the same, break from the loop
					break;
				}
			}
			i += counter; //Move to new word (index of first word plus number of occurrences)
			wordsArray.add(new Word(firstWord, counter));
			uniqueWords++; //Increase number of unique words
			
		}
		
		System.out.println("Number of words: " +uniqueWords); //print number of unique words to console (Number of unique words is the number of words excluding duplicates)
	
		}catch(Exception ex){
			System.out.println(ex);
		}
	}
	
	/**
	 * Takes list of Word instances and exports the object's name and number of occurrences to file
	 */
	public void exportWordsArray(){
		try{
		BufferedWriter bw = new BufferedWriter(new FileWriter("HW5"));
		for(Word n : wordsArray){
			bw.write(n.getWord());
			bw.write("  "+n.getOccurrences());
			bw.newLine();
		}
		bw.close();
		}catch(Exception ex){
			System.out.println(ex);
		}
	}
}
