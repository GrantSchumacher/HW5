
public class Word {
	String name;
	int occurrences;
	
	public Word(String n, int o){
		name = n;
		occurrences = o;
	}
	public String getWord(){
		return name;
	}
	public void setWord(String newWord){
		name = newWord;
	}
	public int getOccurrences(){
		return occurrences;	
	}
	public void setOccurrences(int newOccurrences){
		occurrences = newOccurrences;
	}
	
}
